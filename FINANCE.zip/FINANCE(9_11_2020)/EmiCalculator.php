<?php
    
/**
    * Name : emiCalculator
    * Purpose : To calculate monthly EMI 
    * Input : pricipal amount,intrest,number of months
    * Returns : emi
*/    

# custom exception class months
class months extends Exception
{

}

# custom exception class intrest
class intrest extends Exception
{

}

/**
    * Name : emiCalculator
    * Purpose : To calculate monthly EMI 
    * Input : pricipal amount,intrest,number of months
    * Returns : emi
*/    
function emiCalculator($amount, $intrest, $months) 
{ 
    $emi; 

    # iterate until amount is > 0 
    while($amount <=0)
    {
        $amount = readline("principal amount should be > 0 : ");
    }

    
    try{
        if($intrest<=0){
            throw new intrest();
        }
    }catch(intrest $i){
        return "Exception : intrest can not be < = 0";
    }

    try{
        if($months<=0){
            throw new months();
        }
    }catch(months $m){
        return "Exception : months can not be < = 0";
    }

    # calculating monthly intrest
    $intrest = $intrest /  (12*100);

    /* Mathematical formula to calculate EMI
        EMI = [P x R x (1+R)^N]/[(1+R)^ (N-1)],
                
        In this formula the variables stand for:

        EMI – the equated monthly installment
        P – the principal or the amount that is borrowed as a loan
        R – the rate of interest that is levied on the loan amount (the interest rate should be a monthly rate)
        N – the tenure of repayment of the loan or the number of monthly installments that you will pay (tenure should be in months)
    */

    # logic for calculating emi
    $emi = ($amount * $intrest * pow(1 + $intrest, $months)) /  (pow(1 + $intrest, $months) - 1); 
        
    # rounding the emi value
    return ceil($emi); 
}

?>